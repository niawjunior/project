--
-- Database : u220965490_water
--
-- --------------------------------------------------
-- ---------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;
--
-- Tabel structure for table `activity`
--
DROP TABLE  IF EXISTS `activity`;
CREATE TABLE `activity` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `user` varchar(10) NOT NULL,
  `time` varchar(20) NOT NULL,
  `date` varchar(20) NOT NULL,
  `atvt` varchar(1000) NOT NULL,
  `note` varchar(1000) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=255 DEFAULT CHARSET=utf8;

INSERT INTO `activity`  VALUES ( "86","admin","01:24:50"," 23-12-2016","แก้ไขข้อมูลระดับน้ำ","แก้ไขข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 3414 | ระดับน้ำ 6 เมตร ");
INSERT INTO `activity`  VALUES ( "87","admin","01:25:03"," 23-12-2016","ยกเลิกเป็นแผนที่หลัก"," ยกเลิกการใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "88","admin","01:25:06"," 23-12-2016","เลือกเป็นแผนที่หลัก"," เลือกใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "89","niaw","14:18:09"," 23-12-2016","แก้ไขข้อมูลระดับน้ำ","แก้ไขข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 3414 | ระดับน้ำ 6 เมตร ");
INSERT INTO `activity`  VALUES ( "90","niaw","15:49:44"," 23-12-2016","แก้ไขข้อมูลระดับน้ำ","แก้ไขข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 3414 | ระดับน้ำ 6 เมตร ");
INSERT INTO `activity`  VALUES ( "91","admin","15:59:13"," 26-12-2016","ยกเลิกเป็นแผนที่หลัก"," ยกเลิกการใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "92","admin","16:00:37"," 26-12-2016","เพิ่มข้อมูลระดับน้ำ","เพิ่มข้อมูล | สถานที่ บึงแก่นนคร | ระดับน้ำ 4 เมตร ");
INSERT INTO `activity`  VALUES ( "93","admin","16:01:15"," 26-12-2016","เพิ่มข้อมูลระดับน้ำ","เพิ่มข้อมูล | สถานที่ บึงแก่นนคร | ระดับน้ำ 4 เมตร ");
INSERT INTO `activity`  VALUES ( "94","admin","16:03:07"," 26-12-2016","แก้ไขข้อมูลระดับน้ำ","แก้ไขข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 3417 | ระดับน้ำ 4 เมตร ");
INSERT INTO `activity`  VALUES ( "95","admin","16:03:27"," 26-12-2016","ลบข้อมูลระดับน้ำ","ลบข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 3417 | ระดับน้ำ 4 เมตร ");
INSERT INTO `activity`  VALUES ( "96","admin","16:03:29"," 26-12-2016","ลบข้อมูลระดับน้ำ","ลบข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 3416 | ระดับน้ำ 4 เมตร ");
INSERT INTO `activity`  VALUES ( "97","niaw","16:06:53"," 26-12-2016","เลือกเป็นแผนที่หลัก"," เลือกใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "98","niaw","16:07:07"," 26-12-2016","ยกเลิกเป็นแผนที่หลัก"," ยกเลิกการใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "99","niaw","16:07:16"," 26-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ บึงหนองฮีใหญ่ | ไอดี 20");
INSERT INTO `activity`  VALUES ( "100","niaw","16:07:39"," 26-12-2016","เพิ่มแผนที่"," เพิ่มข้อมูล | สถานที่ dd");
INSERT INTO `activity`  VALUES ( "101","niaw","16:07:56"," 26-12-2016","ลบแผนที่","ลบข้อมูล | สถานที่ dd | ไอดี 27");
INSERT INTO `activity`  VALUES ( "102","niaw","16:08:10"," 26-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "103","niaw","16:10:27"," 26-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "104","niaw","16:10:39"," 26-12-2016","เลือกเป็นแผนที่หลัก"," เลือกใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "105","admin","17:14:55"," 26-12-2016","เพิ่มรายงาน"," เพิ่มข้อมูล | เรื่อง กกกก");
INSERT INTO `activity`  VALUES ( "106","admin","17:18:42"," 26-12-2016","เพิ่มรายงาน"," เพิ่มข้อมูล | เรื่อง กกกก");
INSERT INTO `activity`  VALUES ( "107","admin","17:36:08"," 26-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง กกกก");
INSERT INTO `activity`  VALUES ( "108","admin","17:36:40"," 26-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง กกกก");
INSERT INTO `activity`  VALUES ( "109","admin","18:16:13"," 26-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง กกกก | ไอดี 38 ");
INSERT INTO `activity`  VALUES ( "110","admin","18:16:36"," 26-12-2016","ลบรายงาน"," ลบข้อมูล | เรื่อง กกกก | ไอดี 38");
INSERT INTO `activity`  VALUES ( "111","admin","22:56:11"," 26-12-2016","เพิ่มสมาชิก"," เพิ่มข้อมูล | ชื่อ test3");
INSERT INTO `activity`  VALUES ( "112","admin","22:56:29"," 26-12-2016","แก้ไขสมาชิก"," แก้ไขข้อมูล | ชื่อ  ไอดี | 25");
INSERT INTO `activity`  VALUES ( "113","admin","22:58:21"," 26-12-2016","แก้ไขสมาชิก"," แก้ไขข้อมูล | ชื่อ  ไอดี | 25");
INSERT INTO `activity`  VALUES ( "114","admin","22:59:50"," 26-12-2016","แก้ไขสมาชิก"," แก้ไขข้อมูล | ชื่อ  ไอดี | 25");
INSERT INTO `activity`  VALUES ( "115","admin","23:07:30"," 26-12-2016","แก้ไขสมาชิก"," แก้ไขข้อมูล | ชื่อ  test3 | ไอดี   25");
INSERT INTO `activity`  VALUES ( "116","admin","23:38:27"," 26-12-2016","ลบสมาชิก"," ลบข้อมูล | ชื่อ  test3 | ไอดี 25");
INSERT INTO `activity`  VALUES ( "117","niawjunior","00:23:39"," 27-12-2016","แก้ไขข้อมูลระดับน้ำ","แก้ไขข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 3414 | ระดับน้ำ 6 เมตร ");
INSERT INTO `activity`  VALUES ( "118","admin","12:25:21"," 27-12-2016","เพิ่มแผนที่"," เพิ่มข้อมูล | สถานที่ ทดสอบ");
INSERT INTO `activity`  VALUES ( "119","admin","12:57:12"," 27-12-2016","เพิ่มแผนที่"," เพิ่มข้อมูล | สถานที่ ทดสอบ");
INSERT INTO `activity`  VALUES ( "120","admin","12:59:21"," 27-12-2016","ลบแผนที่","ลบข้อมูล | สถานที่ ทดสอบ | ไอดี 28");
INSERT INTO `activity`  VALUES ( "121","admin","12:59:40"," 27-12-2016","เพิ่มแผนที่"," เพิ่มข้อมูล | สถานที่ ทดสอบ");
INSERT INTO `activity`  VALUES ( "122","admin","13:01:35"," 27-12-2016","ลบแผนที่","ลบข้อมูล | สถานที่ ทดสอบ | ไอดี 29");
INSERT INTO `activity`  VALUES ( "123","admin","13:01:52"," 27-12-2016","เพิ่มแผนที่"," เพิ่มข้อมูล | สถานที่ ทดสอบ");
INSERT INTO `activity`  VALUES ( "124","admin","13:07:33"," 27-12-2016","ลบแผนที่","ลบข้อมูล | สถานที่ ทดสอบ | ไอดี 30");
INSERT INTO `activity`  VALUES ( "125","admin","13:07:48"," 27-12-2016","เพิ่มแผนที่"," เพิ่มข้อมูล | สถานที่ ทดสอบ");
INSERT INTO `activity`  VALUES ( "126","admin","13:09:14"," 27-12-2016","ลบแผนที่","ลบข้อมูล | สถานที่ ทดสอบ | ไอดี 31");
INSERT INTO `activity`  VALUES ( "127","admin","13:09:26"," 27-12-2016","เพิ่มแผนที่"," เพิ่มข้อมูล | สถานที่ ทดสอบ");
INSERT INTO `activity`  VALUES ( "128","admin","13:27:20"," 27-12-2016","ลบแผนที่","ลบข้อมูล | สถานที่ ทดสอบ | ไอดี 32");
INSERT INTO `activity`  VALUES ( "129","admin","13:27:35"," 27-12-2016","เพิ่มแผนที่"," เพิ่มข้อมูล | สถานที่ ทดสอบ");
INSERT INTO `activity`  VALUES ( "130","admin","16:17:15"," 27-12-2016","ยกเลิกเป็นแผนที่หลัก"," ยกเลิกการใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "131","admin","16:17:19"," 27-12-2016","เลือกเป็นแผนที่หลัก"," เลือกใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "132","admin","16:17:26"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ บึงหนองฮีใหญ่ | ไอดี 20");
INSERT INTO `activity`  VALUES ( "133","admin","16:17:34"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ บึงหนองฮีใหญ่ | ไอดี 20");
INSERT INTO `activity`  VALUES ( "134","admin","16:17:37"," 27-12-2016","เลือกเป็นแผนที่หลัก"," เลือกใช้ข้อมูล | สถานที่ บึงหนองฮีใหญ่ | ไอดี 20");
INSERT INTO `activity`  VALUES ( "135","admin","16:17:39"," 27-12-2016","เลือกเป็นแผนที่หลัก"," เลือกใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "136","admin","16:20:53"," 27-12-2016","เพิ่มแผนที่"," เพิ่มข้อมูล | สถานที่ ทดสอบ");
INSERT INTO `activity`  VALUES ( "137","admin","16:24:56"," 27-12-2016","เพิ่มสมาชิก"," เพิ่มข้อมูล | ชื่อ test3");
INSERT INTO `activity`  VALUES ( "138","admin","16:25:01"," 27-12-2016","แก้ไขสมาชิก"," แก้ไขข้อมูล | ชื่อ  test3 | ไอดี   26");
INSERT INTO `activity`  VALUES ( "139","admin","16:25:03"," 27-12-2016","ลบสมาชิก"," ลบข้อมูล | ชื่อ  test3 | ไอดี 26");
INSERT INTO `activity`  VALUES ( "140","admin","16:25:05"," 27-12-2016","ลบสมาชิก"," ลบข้อมูล | ชื่อ  test2 | ไอดี 24");
INSERT INTO `activity`  VALUES ( "141","admin","16:25:10"," 27-12-2016","ลบสมาชิก"," ลบข้อมูล | ชื่อ  test1 | ไอดี 23");
INSERT INTO `activity`  VALUES ( "142","admin","16:25:16"," 27-12-2016","แก้ไขสมาชิก"," แก้ไขข้อมูล | ชื่อ  niawjunior | ไอดี   22");
INSERT INTO `activity`  VALUES ( "143","admin","16:27:47"," 27-12-2016","เพิ่มแผนที่"," เพิ่มข้อมูล | สถานที่ ทดสอบ1");
INSERT INTO `activity`  VALUES ( "144","admin","16:28:24"," 27-12-2016","ลบแผนที่","ลบข้อมูล | สถานที่ ทดสอบ1 | ไอดี 35");
INSERT INTO `activity`  VALUES ( "145","admin","16:37:41"," 27-12-2016","เพิ่มแผนที่"," เพิ่มข้อมูล | สถานที่ ");
INSERT INTO `activity`  VALUES ( "146","admin","16:37:43"," 27-12-2016","ลบแผนที่","ลบข้อมูล | สถานที่  | ไอดี 36");
INSERT INTO `activity`  VALUES ( "147","admin","16:56:09"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "148","admin","16:57:21"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "149","admin","17:05:16"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "150","admin","18:19:05"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "151","admin","18:19:21"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "152","admin","18:20:51"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "153","admin","18:22:55"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "154","admin","18:23:05"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "155","admin","18:23:57"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "156","admin","18:32:32"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "157","admin","18:34:10"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "158","admin","18:36:45"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "159","admin","18:37:27"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "160","admin","18:38:00"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "161","admin","18:38:22"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "162","admin","18:39:38"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "163","admin","18:40:20"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "164","admin","18:41:53"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "165","admin","18:42:20"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "166","admin","18:43:19"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "167","admin","18:44:45"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "168","admin","18:44:55"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "169","admin","18:45:08"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "170","admin","18:45:24"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "171","admin","18:45:43"," 27-12-2016","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "172","admin","19:05:19"," 27-12-2016","แก้ไขข้อมูลระดับน้ำ","แก้ไขข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 3414 | ระดับน้ำ 6 เมตร ");
INSERT INTO `activity`  VALUES ( "173","admin","19:05:31"," 27-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ss | ไอดี 36 ");
INSERT INTO `activity`  VALUES ( "174","admin","19:05:56"," 27-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ระวังน้ำท่วม | ไอดี 36 ");
INSERT INTO `activity`  VALUES ( "175","admin","19:06:13"," 27-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ระวังน้ำท่วม | ไอดี 36 ");
INSERT INTO `activity`  VALUES ( "176","admin","21:02:23"," 27-12-2016","ลบรายงาน"," ลบข้อมูล | เรื่อง ระวังน้ำท่วม | ไอดี 36");
INSERT INTO `activity`  VALUES ( "177","admin","21:02:30"," 27-12-2016","เพิ่มรายงาน"," เพิ่มข้อมูล | เรื่อง กกกก");
INSERT INTO `activity`  VALUES ( "178","admin","21:02:34"," 27-12-2016","ลบรายงาน"," ลบข้อมูล | เรื่อง กกกก | ไอดี 39");
INSERT INTO `activity`  VALUES ( "179","admin","21:26:06"," 27-12-2016","ลบแผนที่","ลบข้อมูล | สถานที่ ทดสอบ | ไอดี 34");
INSERT INTO `activity`  VALUES ( "180","admin","21:26:13"," 27-12-2016","เพิ่มแผนที่"," เพิ่มข้อมูล | สถานที่ ทดสอบ");
INSERT INTO `activity`  VALUES ( "181","admin","11:20:19"," 28-12-2016","เพิ่มรายงาน"," เพิ่มข้อมูล | เรื่อง ทดสอบ");
INSERT INTO `activity`  VALUES ( "182","admin","11:20:32"," 28-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ทดสอบ | ไอดี 40 ");
INSERT INTO `activity`  VALUES ( "183","admin","11:20:46"," 28-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ทดสอบ | ไอดี 40 ");
INSERT INTO `activity`  VALUES ( "184","admin","11:20:52"," 28-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ทดสอบ | ไอดี 40 ");
INSERT INTO `activity`  VALUES ( "185","admin","11:36:09"," 28-12-2016","ลบรายงาน"," ลบข้อมูล | เรื่อง ทดสอบ | ไอดี 40");
INSERT INTO `activity`  VALUES ( "186","admin","11:36:18"," 28-12-2016","เพิ่มรายงาน"," เพิ่มข้อมูล | เรื่อง ทดสอบ");
INSERT INTO `activity`  VALUES ( "187","admin","12:09:14"," 28-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ทดสอบ | ไอดี 41 ");
INSERT INTO `activity`  VALUES ( "188","admin","12:09:23"," 28-12-2016","ลบรายงาน"," ลบข้อมูล | เรื่อง ทดสอบ | ไอดี 41");
INSERT INTO `activity`  VALUES ( "189","admin","12:10:09"," 28-12-2016","เพิ่มรายงาน"," เพิ่มข้อมูล | เรื่อง ทดสอบ");
INSERT INTO `activity`  VALUES ( "190","admin","12:11:15"," 28-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ทดสอบ | ไอดี 42 ");
INSERT INTO `activity`  VALUES ( "191","admin","12:11:29"," 28-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ทดสอบ | ไอดี 42 ");
INSERT INTO `activity`  VALUES ( "192","admin","12:11:49"," 28-12-2016","ลบรายงาน"," ลบข้อมูล | เรื่อง ทดสอบ | ไอดี 42");
INSERT INTO `activity`  VALUES ( "193","admin","12:11:56"," 28-12-2016","เพิ่มรายงาน"," เพิ่มข้อมูล | เรื่อง ทดสอบ");
INSERT INTO `activity`  VALUES ( "194","admin","12:13:17"," 28-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ทดสอบ | ไอดี 43 ");
INSERT INTO `activity`  VALUES ( "195","admin","12:13:51"," 28-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ทดสอบ | ไอดี 43 ");
INSERT INTO `activity`  VALUES ( "196","admin","12:14:06"," 28-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ทดสอบ | ไอดี 43 ");
INSERT INTO `activity`  VALUES ( "197","admin","12:15:27"," 28-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ทดสอบ | ไอดี 43 ");
INSERT INTO `activity`  VALUES ( "198","admin","12:15:38"," 28-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ทดสอบ | ไอดี 43 ");
INSERT INTO `activity`  VALUES ( "199","admin","12:15:45"," 28-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ทดสอบ | ไอดี 43 ");
INSERT INTO `activity`  VALUES ( "200","admin","12:20:18"," 28-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ทดสอบ | ไอดี 43 ");
INSERT INTO `activity`  VALUES ( "201","admin","12:20:37"," 28-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ทดสอบ | ไอดี 43 ");
INSERT INTO `activity`  VALUES ( "202","niaw","12:22:03"," 28-12-2016","แก้ไขรายงาน"," แก้ไขข้อมูล | เรื่อง ทดสอบ | ไอดี 43 ");
INSERT INTO `activity`  VALUES ( "203","admin","13:29:07"," 28-12-2016","แก้ไขข้อมูลระดับน้ำ","แก้ไขข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 3414 | ระดับน้ำ 6 เมตร ");
INSERT INTO `activity`  VALUES ( "204","admin","19:23:24"," 28-12-2016","แก้ไขสมาชิก"," แก้ไขข้อมูล | ชื่อ  niawjunior | ไอดี   22");
INSERT INTO `activity`  VALUES ( "205","admin","19:57:57"," 28-12-2016","แก้ไขสมาชิก"," แก้ไขข้อมูล | ชื่อ  niawjunior | ไอดี   22");
INSERT INTO `activity`  VALUES ( "206","admin","19:58:09"," 28-12-2016","แก้ไขสมาชิก"," แก้ไขข้อมูล | ชื่อ  niawjunior | ไอดี   22");
INSERT INTO `activity`  VALUES ( "207","admin","19:58:17"," 28-12-2016","แก้ไขสมาชิก"," แก้ไขข้อมูล | ชื่อ  niawjunior | ไอดี   22");
INSERT INTO `activity`  VALUES ( "208","admin","15:35:33"," 29-12-2016","เพิ่มแผนที่"," เพิ่มข้อมูล | สถานที่ dd");
INSERT INTO `activity`  VALUES ( "209","admin","15:39:18"," 29-12-2016","ลบแผนที่","ลบข้อมูล | สถานที่ ทดสอบ | ไอดี 37");
INSERT INTO `activity`  VALUES ( "210","admin","15:39:26"," 29-12-2016","เพิ่มแผนที่"," เพิ่มข้อมูล | สถานที่ dd");
INSERT INTO `activity`  VALUES ( "211","admin","15:39:39"," 29-12-2016","ลบแผนที่","ลบข้อมูล | สถานที่ dd | ไอดี 39");
INSERT INTO `activity`  VALUES ( "212","admin","15:39:54"," 29-12-2016","เพิ่มแผนที่"," เพิ่มข้อมูล | สถานที่ dd");
INSERT INTO `activity`  VALUES ( "213","admin","15:40:07"," 29-12-2016","ลบแผนที่","ลบข้อมูล | สถานที่ dd | ไอดี 40");
INSERT INTO `activity`  VALUES ( "214","admin","15:40:53"," 29-12-2016","เพิ่มแผนที่"," เพิ่มข้อมูล | สถานที่ ทดสอบ");
INSERT INTO `activity`  VALUES ( "215","admin","20:23:28"," 29-12-2016","ลบสมาชิก"," ลบข้อมูล | ชื่อ  test4ttt | ไอดี 45");
INSERT INTO `activity`  VALUES ( "216","test4","20:34:12"," 29-12-2016","เพิ่มสมาชิก"," เพิ่มข้อมูล | ชื่อ testt");
INSERT INTO `activity`  VALUES ( "217","admin","20:53:49"," 29-12-2016","ลบสมาชิก"," ลบข้อมูล | ชื่อ  testt | ไอดี 47");
INSERT INTO `activity`  VALUES ( "218","admin","20:53:50"," 29-12-2016","ลบสมาชิก"," ลบข้อมูล | ชื่อ  test4 | ไอดี 46");
INSERT INTO `activity`  VALUES ( "219","admin","20:44:38"," 30-12-2016","ยกเลิกเป็นแผนที่หลัก"," ยกเลิกการใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "220","admin","20:45:27"," 30-12-2016","เพิ่มข้อมูลระดับน้ำ","เพิ่มข้อมูล | สถานที่ บึงแก่นนคร | ระดับน้ำ 6 เมตร ");
INSERT INTO `activity`  VALUES ( "221","admin","20:45:51"," 30-12-2016","เพิ่มข้อมูลระดับน้ำ","เพิ่มข้อมูล | สถานที่ บึงแก่นนคร | ระดับน้ำ 6.1 เมตร ");
INSERT INTO `activity`  VALUES ( "222","admin","20:54:05"," 30-12-2016","เพิ่มข้อมูลระดับน้ำ","เพิ่มข้อมูล | สถานที่ บึงแก่นนคร | ระดับน้ำ 6.2 เมตร ");
INSERT INTO `activity`  VALUES ( "223","admin","20:54:20"," 30-12-2016","เพิ่มข้อมูลระดับน้ำ","เพิ่มข้อมูล | สถานที่ บึงแก่นนคร | ระดับน้ำ 6.4 เมตร ");
INSERT INTO `activity`  VALUES ( "224","admin","21:06:54"," 30-12-2016","เลือกเป็นแผนที่หลัก"," เลือกใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "225","admin","21:09:03"," 30-12-2016","ยกเลิกเป็นแผนที่หลัก"," ยกเลิกการใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "226","admin","21:10:28"," 30-12-2016","แก้ไขข้อมูลระดับน้ำ","แก้ไขข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 3421 | ระดับน้ำ 6.4 เมตร ");
INSERT INTO `activity`  VALUES ( "227","admin","21:11:14"," 30-12-2016","เลือกเป็นแผนที่หลัก"," เลือกใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "228","admin","20:47:25"," 31-12-2016","ลบข้อมูลระดับน้ำ","ลบข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 3422 | ระดับน้ำ 2 เมตร ");
INSERT INTO `activity`  VALUES ( "229","admin","20:49:05"," 31-12-2016","ยกเลิกเป็นแผนที่หลัก"," ยกเลิกการใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "230","admin","20:51"," 31-12-2016","ลบข้อมูลระดับน้ำ","ลบข้อมูล | สถานที่  | ไอดี 3423 | ระดับน้ำ 0 เมตร ");
INSERT INTO `activity`  VALUES ( "231","admin","20:53:30"," 31-12-2016","ลบข้อมูลระดับน้ำ","ลบข้อมูล | สถานที่  | ไอดี 3427 | ระดับน้ำ 0 เมตร ");
INSERT INTO `activity`  VALUES ( "232","admin","20:53:33"," 31-12-2016","ลบข้อมูลระดับน้ำ","ลบข้อมูล | สถานที่  | ไอดี 3426 | ระดับน้ำ 0 เมตร ");
INSERT INTO `activity`  VALUES ( "233","admin","20:53:35"," 31-12-2016","ลบข้อมูลระดับน้ำ","ลบข้อมูล | สถานที่  | ไอดี 3425 | ระดับน้ำ 0 เมตร ");
INSERT INTO `activity`  VALUES ( "234","admin","20:53:38"," 31-12-2016","ลบข้อมูลระดับน้ำ","ลบข้อมูล | สถานที่  | ไอดี 3424 | ระดับน้ำ 0 เมตร ");
INSERT INTO `activity`  VALUES ( "235","admin","20:54:44"," 31-12-2016","เลือกเป็นแผนที่หลัก"," เลือกใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "236","admin","20:55:27"," 31-12-2016","ลบข้อมูลระดับน้ำ","ลบข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 3428 | ระดับน้ำ 2 เมตร ");
INSERT INTO `activity`  VALUES ( "237","admin","20:55:48"," 31-12-2016","ยกเลิกเป็นแผนที่หลัก"," ยกเลิกการใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "238","admin","20:55:51"," 31-12-2016","ลบข้อมูลระดับน้ำ","ลบข้อมูล | สถานที่  | ไอดี  | ระดับน้ำ  เมตร ");
INSERT INTO `activity`  VALUES ( "239","admin","20:56:00"," 31-12-2016","เพิ่มข้อมูลระดับน้ำ","เพิ่มข้อมูล | สถานที่ บึงแก่นนคร | ระดับน้ำ  เมตร ");
INSERT INTO `activity`  VALUES ( "240","admin","22:28:55"," 31-12-2016","เลือกเป็นแผนที่หลัก"," เลือกใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "241","admin","22:29:05"," 31-12-2016","แก้ไขข้อมูลระดับน้ำ","แก้ไขข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 3421 | ระดับน้ำ 6.4 เมตร ");
INSERT INTO `activity`  VALUES ( "242","admin","23:15:23"," 03-01-2017","ลบรายงาน"," ลบข้อมูล | เรื่อง ทดสอบ | ไอดี 43");
INSERT INTO `activity`  VALUES ( "243","admin","23:15:25"," 03-01-2017","ลบรายงาน"," ลบข้อมูล | เรื่อง ss | ไอดี 35");
INSERT INTO `activity`  VALUES ( "244","admin","23:15:26"," 03-01-2017","ลบรายงาน"," ลบข้อมูล | เรื่อง ss | ไอดี 34");
INSERT INTO `activity`  VALUES ( "245","admin","23:16:19"," 03-01-2017","เพิ่มรายงาน"," เพิ่มข้อมูล | เรื่อง ทดสอบระบบรายงานผล");
INSERT INTO `activity`  VALUES ( "246","admin","16:20:42"," 04-01-2017","ยกเลิกเป็นแผนที่หลัก"," ยกเลิกการใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "247","admin","16:20:45"," 04-01-2017","ยกเลิกเป็นแผนที่หลัก"," ยกเลิกการใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "248","admin","16:21:01"," 04-01-2017","เลือกเป็นแผนที่หลัก"," เลือกใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "249","admin","16:21:40"," 04-01-2017","ยกเลิกเป็นแผนที่หลัก"," ยกเลิกการใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "250","admin","16:21:56"," 04-01-2017","เพิ่มข้อมูลระดับน้ำ","เพิ่มข้อมูล | สถานที่ บึงทุ่งสร้าง | ระดับน้ำ 6.2 เมตร ");
INSERT INTO `activity`  VALUES ( "251","admin","16:22:09"," 04-01-2017","เลือกเป็นแผนที่หลัก"," เลือกใช้ข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 9");
INSERT INTO `activity`  VALUES ( "252","admin","16:25:47"," 04-01-2017","เพิ่มรายงาน"," เพิ่มข้อมูล | เรื่อง ทดสอบระบบรายงานผล1");
INSERT INTO `activity`  VALUES ( "253","admin","16:31:22"," 04-01-2017","แก้ไขแผนที่"," แก้ไขข้อมูล | สถานที่ ทดสอบ | ไอดี 41");
INSERT INTO `activity`  VALUES ( "254","admin","16:35:17"," 04-01-2017","ลบข้อมูลระดับน้ำ","ลบข้อมูล | สถานที่ บึงแก่นนคร | ไอดี 3418 | ระดับน้ำ 6 เมตร ");


--
-- Tabel structure for table `data`
--
DROP TABLE  IF EXISTS `data`;
CREATE TABLE `data` (
  `ID` int(20) NOT NULL AUTO_INCREMENT,
  `h1` varchar(100) NOT NULL,
  `h2` varchar(500) NOT NULL,
  `la` varchar(20) NOT NULL,
  `lo` varchar(20) NOT NULL,
  `deep` varchar(20) NOT NULL,
  `url` varchar(100) NOT NULL,
  `level` varchar(20) NOT NULL,
  `time` varchar(10) NOT NULL,
  `date` varchar(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

INSERT INTO `data`  VALUES ( "9","บึงแก่นนคร","ตำบล พระลับ อำเภอเมืองขอนแก่น ขอนแก่น 40000 ประเทศไทย","16.412998","102.838256","8","บึงแก่นนคร.png","6.4","23:13","2016-12-16");
INSERT INTO `data`  VALUES ( "10","บึงทุ่งสร้าง","ตำบล ในเมือง อำเภอเมืองขอนแก่น","16.444262","102.859017","10","บึงทุ่งสร้าง.png","8.6","23:25:09","23-08-2016");
INSERT INTO `data`  VALUES ( "11","บึงหนองโคตร","ตำบล บ้านเป็ด อำเภอเมืองขอนแก่น","16.432377","102.798158","5","บึงหนองโคตร.png","4","18:42","01-10-2016");
INSERT INTO `data`  VALUES ( "19","บึงศรีฐาน","Mueang Khon Kaen ","16.443734","102.8121","9","บึงศรีฐาน.png","4","18:42","07-10-2016");
INSERT INTO `data`  VALUES ( "20","บึงหนองฮีใหญ่","Amphoe Mueang Khon Kaen","16.42469914317164","102.81677953898907","14","4.jpg","9.2","22:25:09","20-08-2016");
INSERT INTO `data`  VALUES ( "41","ทดสอบ","ทดสอบ","16.432691881961887","102.81823128461838","7","1483522282-00.jpg","","","");


--
-- Tabel structure for table `member`
--
DROP TABLE  IF EXISTS `member`;
CREATE TABLE `member` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `user` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `pass` varchar(300) NOT NULL,
  `email` varchar(50) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `on_off` varchar(10) NOT NULL,
  `img` varchar(300) NOT NULL,
  `time` varchar(10) NOT NULL,
  `date` varchar(10) NOT NULL,
  `lastactivity` varchar(100) NOT NULL,
  `countatvt` int(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

INSERT INTO `member`  VALUES ( "1","admin","pasupol bunsaen","123456","niawkung2@gmail.com","ชาย","0883204253","ADMIN","ONLINE","https://scontent.fbkk13-1.fna.fbcdn.net/v/l/t1.0-9/15578794_1601402416834376_8627602776759047543_n.jpg?oh=26a4cd5411dbef13b845a859b28b0195&oe=58E622C1","16:24:03","04-01-2017","ลบข้อมูล | สถานที่ บึงแก่นนคร | ระดับน้ำ 6 เมตร ","156");
INSERT INTO `member`  VALUES ( "11","niaw","พสุพล บุญแสน","1234","niawkung2@gmail.com","ชาย","0883204253","ADMIN","OFFLINE","https://s3-ap-southeast-1.amazonaws.com/fastwork-test/cada3fb2-d886-430b-9034-67a88163876b/products/dacfecfb-52b1-4c88-b792-ed4c87156272/ixShvdLx_med.jpg","17:14:08","31-12-2016","แก้ไขรายงาน | เรื่อง ทดสอบ","11");
INSERT INTO `member`  VALUES ( "48","niawjunior","","123456","niawkung2@gmail.com","","","USER","OFFLINE","","17:14:46","31-12-2016","","0");
INSERT INTO `member`  VALUES ( "49","niawjunior1","pasupol bunsaen","123456","niawkung2@gmail.com","ชาย","0883204253","ADMIN","OFFLINE","https://scontent.fbkk13-1.fna.fbcdn.net/v/t31.0-8/s960x960/15625891_1602550763386208_2772831771400338860_o.jpg?oh=3148d5fbc36eeed1cebc519ce6b9a2fe&oe=591F53BE","17:20:31","31-12-2016","","0");


--
-- Tabel structure for table `setting`
--
DROP TABLE  IF EXISTS `setting`;
CREATE TABLE `setting` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `type_register` varchar(20) NOT NULL,
  `type_activity` varchar(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `setting`  VALUES ( "1","A1","");


--
-- Tabel structure for table `showdata`
--
DROP TABLE  IF EXISTS `showdata`;
CREATE TABLE `showdata` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `showh1` varchar(100) NOT NULL,
  `showh2` varchar(200) NOT NULL,
  `showla` varchar(20) NOT NULL,
  `showlo` varchar(20) NOT NULL,
  `showdeep` varchar(20) NOT NULL,
  `showurl` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=185 DEFAULT CHARSET=utf8;

INSERT INTO `showdata`  VALUES ( "184","บึงแก่นนคร","ตำบล พระลับ อำเภอเมืองขอนแก่น ขอนแก่น 40000 ประเทศไทย","16.412998","102.838256","8","บึงแก่นนคร.png");


--
-- Tabel structure for table `upload`
--
DROP TABLE  IF EXISTS `upload`;
CREATE TABLE `upload` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `t2` varchar(50) NOT NULL,
  `url` varchar(30) NOT NULL,
  `date` varchar(10) NOT NULL,
  `postby` varchar(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

INSERT INTO `upload`  VALUES ( "45","ทดสอบระบบรายงานผล1","1483521947-doc.pdf","2017-01-16","admin");
INSERT INTO `upload`  VALUES ( "44","ทดสอบระบบรายงานผล","1483460179-doc.pdf","2017-01-04","admin");


--
-- Tabel structure for table `water_table`
--
DROP TABLE  IF EXISTS `water_table`;
CREATE TABLE `water_table` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `place` varchar(20) NOT NULL,
  `level` float NOT NULL,
  `deep` varchar(20) NOT NULL,
  `time` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3423 DEFAULT CHARSET=utf8;

INSERT INTO `water_table`  VALUES ( "3414","บึงแก่นนคร","6"," 8","01:00","2016-12-06");
INSERT INTO `water_table`  VALUES ( "3419","บึงแก่นนคร","6.1"," 8","14:03","2016-12-14");
INSERT INTO `water_table`  VALUES ( "3420","บึงแก่นนคร","6.2"," 8","12:45","2016-12-15");
INSERT INTO `water_table`  VALUES ( "3421","บึงแก่นนคร","6.4"," 8","23:13","2016-12-16");
INSERT INTO `water_table`  VALUES ( "3422","บึงทุ่งสร้าง","6.2"," 10","13:03","2017-01-19");


SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
